package com.foodbox.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foodbox.app.entity.Contact;

public interface ContactAdmRepository extends JpaRepository<Contact, Long> 
{
	
}
