package com.foodbox.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foodbox.app.entity.Product;

public interface ProductAdmRepository extends JpaRepository<Product, Long> {
}
