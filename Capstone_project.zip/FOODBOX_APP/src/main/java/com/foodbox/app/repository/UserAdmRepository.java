package com.foodbox.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foodbox.app.entity.Customer;

public interface UserAdmRepository extends JpaRepository<Customer,Long>
{

}
