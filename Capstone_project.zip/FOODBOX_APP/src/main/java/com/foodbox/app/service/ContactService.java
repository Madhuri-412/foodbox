package com.foodbox.app.service;

import javax.mail.MessagingException;

import com.foodbox.app.entity.Contact;

public interface ContactService {
	
	void saveContacts(Contact contact) throws MessagingException;

}
